The comments are related to how the code relates to the math found in Bishop book "Neural Networks for Pattern Recognition".



